import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-ciag',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './ciag.component.html',
  styleUrl: './ciag.component.css'
})
export class CiagComponent {
  wyraz_pierwszy:number = 0
  roznica_ciagu:number = 0
  n_wyrazow:number = 0
  wyrazy:number [] = []

  generujCiag(){
    console.log(this.wyraz_pierwszy, this.roznica_ciagu, this.n_wyrazow)
    this.wyrazy = []
    
  
    for(let i = this.wyraz_pierwszy; this.wyrazy.length < this.n_wyrazow; i = i + this.roznica_ciagu){
      this.wyrazy.push(i);
    }
}
}